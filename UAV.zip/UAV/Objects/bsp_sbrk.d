./objects/bsp_sbrk.o: \
  C:/Users/13750/RASmartConfigurator/adc_test_32/ra/fsp/src/bsp/mcu/all/bsp_sbrk.c
