/* generated configuration header file - do not edit */
#ifndef BSP_PIN_CFG_H_
#define BSP_PIN_CFG_H_
#include "r_ioport.h"

/* Common macro for FSP header files. There is also a corresponding FSP_FOOTER macro at the end of this file. */
FSP_HEADER

#define led (BSP_IO_PORT_00_PIN_10)
#define alarm (BSP_IO_PORT_00_PIN_15)
#define key_1 (BSP_IO_PORT_06_PIN_00)
#define key_2 (BSP_IO_PORT_06_PIN_01)
#define key_3 (BSP_IO_PORT_06_PIN_02)
extern const ioport_cfg_t g_bsp_pin_cfg; /* R7FA6M5BF2CBG.pincfg */

void BSP_PinConfigSecurityInit();

/* Common macro for FSP header files. There is also a corresponding FSP_HEADER macro at the top of this file. */
FSP_FOOTER

#endif /* BSP_PIN_CFG_H_ */
