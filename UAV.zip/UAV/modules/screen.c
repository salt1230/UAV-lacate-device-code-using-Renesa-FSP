#include "hal_data.h"

uint8_t fre_com[8] = {0xA5,0x5A,0x05,0x82,0x00,0x00}; // дƵ��,����λ6��7
uint8_t x_com[8]   = {0xA5,0x5A,0x05,0x82,0x00,0x08}; // дx����,����λ6��7
uint8_t y_com[8]   = {0xA5,0x5A,0x05,0x82,0x00,0x0C}; // дy����,����λ6��7
uint8_t xy_ang_com[8] = {0xA5,0x5A,0x05,0x82,0x00,0x10}; // д��λ��,����λ6��7
uint8_t z_ang_com[8]  = {0xA5,0x5A,0x05,0x82,0x00,0x14}; // д������,����λ6��7
uint8_t dis_com[8] = {0xA5,0x5A,0x05,0x82,0x00,0x04}; // д����,����λ6��7

// Ŀ��λ�û�Բ������λ11��12��x��13��14��y
uint8_t target_com[18] = {0xA5,0x5A,0x0F,0x82,0x00,0x20,0x00,0x05,0x00,0x01,0x00,0x00,0x00,0x00,0x00,0x03,0xF8,0x00};
// Ŀ��λ�ú�ԭ�����ߣ�����λ13��14��x��15��16��y
uint8_t line_com[20]   = {0xA5,0x5A,0x11,0x82,0x00,0x30,0x00,0x02,0x00,0x01,0xF8,0x00,0x00,0x00,0x00,0x00,0x00,0x93,0x00,0x94}; 
	
void Screen_Init(void)
{
	  fsp_err_t err;
    err = screen_uart.p_api->open(screen_uart.p_ctrl, screen_uart.p_cfg);
}

void show_fre(uint16_t freq)
{
  uint8_t high_byte = (freq >> 8) & 0xFF; 
  uint8_t low_byte  = freq & 0xFF;        
	  
	fre_com[6] = high_byte;
  fre_com[7] = low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,fre_com,8);
}

void show_x_y(uint16_t x,uint16_t y)
{
  uint8_t x_high_byte = (x >> 8) & 0xFF; 
  uint8_t x_low_byte  = x & 0xFF; 
	
  uint8_t y_high_byte = (y >> 8) & 0xFF; 
  uint8_t y_low_byte  = y & 0xFF;	
	  
	x_com[6] = x_high_byte;
  x_com[7] = x_low_byte;
	
	y_com[6] = y_high_byte;
  y_com[7] = y_low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,x_com,8);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_MILLISECONDS);
	R_SCI_UART_Write(&screen_uart_ctrl,y_com,8);
}

void show_xy_ang(uint16_t xy_ang)
{
  uint8_t high_byte = (xy_ang >> 8) & 0xFF; 
  uint8_t low_byte  = xy_ang & 0xFF;        
	  
	xy_ang_com[6] = high_byte;
  xy_ang_com[7] = low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,xy_ang_com,8);
}

void show_z_ang(uint16_t z_ang)
{
  uint8_t high_byte = (z_ang >> 8) & 0xFF; 
  uint8_t low_byte  = z_ang & 0xFF;        
	  
	z_ang_com[6] = high_byte;
  z_ang_com[7] = low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,z_ang_com,8);
}

void show_dis(uint16_t dis)
{
  uint8_t high_byte = (dis >> 8) & 0xFF; 
  uint8_t low_byte  = dis & 0xFF;        
	  
	dis_com[6] = high_byte;
  dis_com[7] = low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,dis_com,8);
}

void show_target(uint16_t x,uint16_t y)
{
  uint8_t x_high_byte = (x >> 8) & 0xFF; 
  uint8_t x_low_byte  = x & 0xFF; 
	
  uint8_t y_high_byte = (y >> 8) & 0xFF; 
  uint8_t y_low_byte  = y & 0xFF;	
	  
	target_com[10] = x_high_byte;
  target_com[11] = x_low_byte;
	
	target_com[12] = y_high_byte;
  target_com[13] = y_low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,target_com,18);
}

void show_line(uint16_t x,uint16_t y)
{
  uint8_t x_high_byte = (x >> 8) & 0xFF; 
  uint8_t x_low_byte  = x & 0xFF; 
	
  uint8_t y_high_byte = (y >> 8) & 0xFF; 
  uint8_t y_low_byte  = y & 0xFF;	
	  
	line_com[12] = x_high_byte;
  line_com[13] = x_low_byte;
	
	line_com[14] = y_high_byte;
  line_com[15] = y_low_byte;
	
	R_SCI_UART_Write(&screen_uart_ctrl,line_com,20);
}

void show_on_axis(uint16_t x,uint16_t y)
{
	show_target(x,y);
	R_BSP_SoftwareDelay(10,BSP_DELAY_UNITS_MILLISECONDS);
	show_line(x,y);
	R_BSP_SoftwareDelay(10,BSP_DELAY_UNITS_MILLISECONDS);
}

void screen_test(void)
{
	show_fre(2000);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	show_dis(9999);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	show_x_y(999,999);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	show_xy_ang(36000);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	show_z_ang(9000);
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	show_on_axis(90,90);
	R_BSP_SoftwareDelay(20,BSP_DELAY_UNITS_SECONDS);
}
