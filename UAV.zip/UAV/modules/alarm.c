#include "alarm.h"

void alarm_Init(void)
{
	R_IOPORT_Open(g_ioport.p_ctrl,g_ioport.p_cfg);
}

void alarm_on(void)
{
	ALARM_ON;
}

void alarm_off(void)
{
	ALARM_OFF;
}

void alarm_test(void)
{
	alarm_on();
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	alarm_off();
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
}
