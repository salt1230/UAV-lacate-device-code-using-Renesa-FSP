#ifndef _BOTTON_H
#define _BOTTON_H
#include "hal_data.h"

#define KEY_ON  1
#define KEY_OFF 0

void key_Init(void);
uint8_t getkey1(void);
uint8_t getkey2(void);
uint8_t getkey3(void);
void key1_test(void);
void key2_test(void);
void key3_test(void);

#endif
