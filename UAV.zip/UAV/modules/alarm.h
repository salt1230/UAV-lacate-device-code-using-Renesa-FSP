#ifndef _ALARM_H
#define _ALARM_H
#include "hal_data.h"

#define ALARM_ON   R_IOPORT_PinWrite(g_ioport.p_ctrl, alarm, BSP_IO_LEVEL_HIGH)
#define ALARM_OFF  R_IOPORT_PinWrite(g_ioport.p_ctrl, alarm, BSP_IO_LEVEL_LOW)

void alarm_Init(void);
void alarm_on(void);
void alarm_off(void);
void alarm_test(void);

#endif
