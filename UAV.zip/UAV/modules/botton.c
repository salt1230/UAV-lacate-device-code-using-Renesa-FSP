#include "botton.h"
#include "led.h"

void key_Init(void)
{
	R_IOPORT_Open(g_ioport.p_ctrl,g_ioport.p_cfg);
}

uint8_t getkey1(void)
{
	bsp_io_level_t state;
	R_IOPORT_PinRead(g_ioport.p_ctrl,key_1,&state);
	if (BSP_IO_LEVEL_HIGH == state)
	{
		return KEY_OFF;
	}
	else
	{
		return KEY_ON;
	}
}

uint8_t getkey2(void)
{
	bsp_io_level_t state;
	R_IOPORT_PinRead(g_ioport.p_ctrl,key_2,&state);
	if (BSP_IO_LEVEL_HIGH == state)
	{
		return KEY_OFF;
	}
	else
	{
		return KEY_ON;
	}
}

uint8_t getkey3(void)
{
	bsp_io_level_t state;
	R_IOPORT_PinRead(g_ioport.p_ctrl,key_3,&state);
	if (BSP_IO_LEVEL_HIGH == state)
	{
		return KEY_OFF;
	}
	else
	{
		return KEY_ON;
	}
}

void key1_test(void)
{
	if(getkey1() == 1)
	{
		led_on();
	}
	else
	{
		led_off();
	}
}

void key2_test(void)
{
	if(getkey2() == 1)
	{
		led_on();
	}
	else
	{
		led_off();
	}
}

void key3_test(void)
{
	if(getkey3() == 1)
	{
		led_on();
	}
	else
	{
		led_off();
	}
}
