#ifndef _LED_H
#define _LED_H
#include "hal_data.h"

#define LED_ON   R_IOPORT_PinWrite(g_ioport.p_ctrl, led, BSP_IO_LEVEL_HIGH)
#define LED_OFF  R_IOPORT_PinWrite(g_ioport.p_ctrl, led, BSP_IO_LEVEL_LOW)

void led_Init(void);
void led_on(void);
void led_off(void);
void led_test(void);

#endif
