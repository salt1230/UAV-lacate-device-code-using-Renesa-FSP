#include "led.h"

void led_Init(void)
{
	R_IOPORT_Open(g_ioport.p_ctrl,g_ioport.p_cfg);
}

void led_on(void)
{
	LED_ON;
}

void led_off(void)
{
	LED_OFF;
}

void led_test(void)
{
	led_on();
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
	led_off();
	R_BSP_SoftwareDelay(1,BSP_DELAY_UNITS_SECONDS);
}
	